%% pre-settings
close all; clear all;

[filepart,~,~] = fileparts(pwd);
%% generate data
readDigits_train = 1000;
offset_train = 0;
readDigits_test = 1000;
offset_test = 0;
[imag_train, label_train] = readMNIST('train-images.idx3-ubyte', 'train-labels.idx1-ubyte', readDigits_train, offset_train);
[imag_test, label_test] = readMNIST('t10k-images.idx3-ubyte', 't10k-labels.idx1-ubyte', readDigits_test, offset_train);

savepath = fullfile(filepart,'observations.mat');
save(savepath,'imag_train','label_train','imag_test',...
    'label_test','readDigits_train','offset_train',...
    'readDigits_test','offset_test')

%% plot the image for pca
sample = 7;
figure
imagesc(reshape(imag_train(:,sample),[28,28]));
axis on
title("Sample Image")
